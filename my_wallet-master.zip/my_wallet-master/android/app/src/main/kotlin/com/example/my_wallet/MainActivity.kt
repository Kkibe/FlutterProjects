package com.example.my_wallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
